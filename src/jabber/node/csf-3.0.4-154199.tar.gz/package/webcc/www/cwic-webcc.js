
(function( $ ) {

	var settings = {
        /** A flag to indicate to cwic that it should log more messages.
         * @type Boolean=false
         */
        verbose: false,
        /** Handler to be called when cwic needs to log information.<br>
         * Default is to use console.log if available, otherwise do nothing.
         * @function
         * @param {String} msg the message
         * @param {Object} [context] the context of the message
         * @type Function
         */
        log: function(/** String */msg, /** Object */context) {
            if (typeof console !== "undefined" && console.log) {
                console.log(msg);
                if (context) {
                    console.log(context);
                }
            }
        },
        /** The handler to be called if the API could not be initialized.<br>
         * The basic properties of the error object are listed, however more may be added based on the context of the error.<br>
         * If the triggered error originated from a caught exception, the original error properties are included in the error parameter.<br>
         * An error with code 1 (PluginNotAvailable) can have an extra 'pluginDisabled' property set to true.<br>
         * @type Function
         * @param {Object} error see {@link $.fn.cwic-errorMap}
         * @param {String} [error.message] message associated with the error.
         * @param {Number} error.code code associated with the error
         */
        error: function(/** Object */error) {
            _log("Error: ",error);
        },
	};

    /**
     * an internal function to log messages
     * @param (Boolean) [isVerbose] indicates if msg should be logged in verbose mode only (configurable by the application)  <br>
     * @param (String) msg the message to be logged (to console.log by default, configurable by the application)  <br>
     * @param (Object) [context] a context to be logged <br>
    */
    function _log() {
        var isVerbose = typeof arguments[0] === "boolean" ? arguments[0] : false;
        var msg = typeof arguments[0] === "string" ? arguments[0] : arguments[1];
        var context = typeof arguments[1] === "object" ? arguments[1] : arguments[2];

        if ((!isVerbose || (isVerbose && settings.verbose)) && $.isFunction(settings.log)) {
            settings.log('[cwic] ' + msg, context);
        }
    }

    /** cwic error object
     * @name $.fn.cwic-errorMapEntry
     * @namespace
     * @property {Number} code a unique error code
     * @property {String} message the message associated with the error
     * @property {Any} [propertyName] Additional properties that will be passed back when an error is raised.
     */
    /**
     * The error map used to build errors triggered by cwic. <br>
     * Keys are error codes (numbers), values objects associated to codes. <br>
     * By default the error object contains a single 'message' property. <br>
     * The error map can be customized via the init function. <br>
     * @namespace
     */
    var errorMap = {
        /** 0: unknown error or exception
         * @type $.fn.cwic-errorMapEntry
         */
        Unknown  :                { code:   0, message: "Unknown error" },
        /** 1: plugin not available (not installed, not enabled or unable to load)
         * @type $.fn.cwic-errorMapEntry
         */
        PluginNotAvailable :      { code:   1, message: "Plugin not available" },
        /** 2: browser not supported
         * @type $.fn.cwic-errorMapEntry
         */
        BrowserNotSupported :     { code:   2, message: "Browser not supported" },
        /** 3: invalid arguments
         * @type $.fn.cwic-errorMapEntry
         */
        InvalidArguments :        { code:   3, message: "Invalid arguments" },
        /** 4: invalid state for operation (e.g. startconversation when phone is not registered)
         * @type $.fn.cwic-errorMapEntry
         */
        InvalidState :            { code:   4, message: "Invalid State" },
        /** 5: plugin returned an error
         * @type $.fn.cwic-errorMapEntry
         */
        NativePluginError:        { code:   5, message: "Native plugin error" },
        /** 6: operation not supported
         * @type $.fn.cwic-errorMapEntry
         */
		OperationNotSupported:	  { code:   6, message: "Operation not supported" },
        /** 7: no call manager specified
         * @type $.fn.cwic-errorMapEntry
         */
        ReleaseMismatch :         { code:   7, message: "Release mismatch" },
        /** 10: release mismatch
         * @type $.fn.cwic-errorMapEntry
         */
        NoCallManagerConfigured : { code:  10, message: "No CUCM found" },
        /** 11: no devices found for supplied credentials
         * @type $.fn.cwic-errorMapEntry
         */
        NoDevicesFound :          { code:  11, message: "No devices found" },
        /** 12: no softphone (CSF) devices found for supplied credentials
         * @type $.fn.cwic-errorMapEntry
         */
        NoCsfDevicesFound :       { code:  12, message: "No CSF device found" },
        /** 13: other phone configuration error
         * @type $.fn.cwic-errorMapEntry
         */
        PhoneConfigGenError :     { code:  13, message: "Phone configuration error" },
        /** 14: SIP profile error
         * @type $.fn.cwic-errorMapEntry
         */
        SipProfileGenError :      { code:  14, message: "Sip profile error" },
        /** 15: configuration not set e.g. missing TFTP/CTI/CCMCIP addresses
         * @type $.fn.cwic-errorMapEntry
         */
        ConfigNotSet :            { code:  15, message: "Configuration not set" },
        /** 16: could not fetch phone configuration
         * @type $.fn.cwic-errorMapEntry
         */
        TftpFetchError :          { code:  16, message: "TFTP fetch error" },
        /** 18: already logged in in another process (browser or window in internet explorer)
         * @type $.fn.cwic-errorMapEntry
         */
        LoggedInElseWhere :       { code:  18, message: "Already logged in" },
        /** 19: authentication failed - invalid username or password for configured server
         * @type $.fn.cwic-errorMapEntry
         */
        AuthenticationFailure :   { code:  19, message: "Authentication failed" },
        /** 20: other login error
         * @type $.fn.cwic-errorMapEntry
         */
        LoginError:               { code:  20, message: "Login Error"},
        /** 21: no username and/or password supplied
         * @type $.fn.cwic-errorMapEntry
         */
        NoCredentialsConfigured:  { code:  21, message: "No credentials configured"},
        /** 30: error performing call control operation
         * @type $.fn.cwic-errorMapEntry
         */
        CallControlError:         { code:  30, message: "Call control error"},
        /** 40: error modifying video association (e.g. removing non-attached window or adding non-existing window)
         * @type $.fn.cwic-errorMapEntry
         */
        VideoWindowError:         { code:  40, message: "Video window error"},
        /** 999: no error (success)
         * @type $.fn.cwic-errorMapEntry
         */
        NoError:                  { code: 999, message: "No Error"}
    };

	// the web socket to transport signaling
	// cwic uses socket.io, which is usually included as
	// <script src="/socket.io/socket.io.js"></script>
	var _socket = null;
	
	var _webRTC = {};
  
  	function init(options) {
  		var $this = this;
  		settings.verbose = options.verbose || settings.verbose;
  		
  		/*
  		try {
	  		// check WebRTC is available
  			if ($.isFunction(window.navigator.mozGetUserMedia)) {
  				_webRTC.getUserMedia = function(param, success, error) {
  					window.navigator.mozGetUserMedia(param, success, error);
  				};
  			}
  			else if ($.isFunction(window.navigator.webkitGetUserMedia)) {
  				_webRTC.getUserMedia = function(param, success, error) {
  					window.navigator.webkitGetUserMedia(param, success, error);
  				};
  				
	  			if (typeof window.webkitPeerConnection00 === 'undefined') {
	  				throw errorMap.BrowserNotSupported;
	  			}
  				_webRTC.PeerConnection = window.webkitPeerConnection00;
  				_webRTC.URL = window.webkitURL;
  			}
  			else {
  				throw errorMap.BrowserNotSupported;
  			}
  		}
  		catch (ie) {
  			return _triggerError($this, options.error, ie);
  		}
  		*/
  		
  		// connect the web socket
  		var url = options.url || (/*window.location.origin +*/ '/webcc/socket');
  		_socket = io.connect(url);
  		
  		_socket.on('error', function(data) {
  			if (typeof data === 'string') {
	  			_triggerError($this, errorMap[data] ? errorMap[data] : data);
	  		}
	  		else if (typeof data === 'object') {
	  			_triggerError($this, errorMap[data.key] ? errorMap[data.key] : data);
	  		}
  		});
  		
  		_socket.on('disconnect', function() {
  			_triggerError($this, 'call control disconnected');
  		});
  		
  		_socket.on('connect', function() {
  			_log(true, 'socket connect');
  			if ($.isFunction(options.ready)) { options.ready(); }
  		});
  		
  		return $this;
  	}
  
  	function registerPhone(options) {
  		var $this = this;
  		
  		function _registerPhoneCb(error, registration) {
  			if (error) {
  				return _triggerError($this, options.error, 'cannot register', error);
  			}
  			
  			if ($.isArray(registration.availableDevices)) {
  			    for (var i=0; i<registration.availableDevices.length; i++) {
  			        dev = registration.availableDevices[i];
  			        
  			        if (/^SEP/i.test(dev.name)) { dev.deskphone = true; }
  			        else if (/Cisco Unified Client Services Framework/i.test(dev.model)) { dev.csf = true; }
  			    }
  			    
  			    options.devicesAvailable(registration.availableDevices, options.mode, function(device, mode) {
  			        if (device == false) { return; }
  			        if (device == null)  { device = 'ECP' + options.user; }
  			        
  			        _socket.emit('registerPhone', {
  			            user: options.user,
  			            password: window.btoa(options.password),
  			            cucm: options.cucm,
  			            mode: mode || options.mode,
  			            device: device
  		            },
                    _registerPhoneCb);
  			    });
  			    
  			    return;
  			}
  			
  			_socket.on('conversationUpdate', function(error, conversation) {
  				_log(true, 'conversationUpdate', conversation);
  				$('.cwic-conversation-' + conversation.id).trigger('conversationUpdate.cwic', [conversation]);
  			});
  			
  			_socket.on('conversationEnd', function(error, conversation) {
  				_log(true, 'conversationEnd', conversation);
  				$('.cwic-conversation-' + conversation.id).trigger('conversationEnd.cwic', [conversation]);
  			});
  			
  			_socket.on('conversationIncoming', function(error, conversation) {
  				_log(true, 'conversationIncoming', conversation);
  				var container =
  					$('<div class="cwic-conversation-' + conversation.id + '"></div>')
  						.data('cwic', conversation);
  						
  				$this.trigger('conversationIncoming', [conversation, container]);
  			});
  			
  			if ($.isFunction(options.success)) { options.success(registration); }
  		} // _registerPhoneCb
  		
  		_socket.emit('registerPhone', {
  			user: options.user,
  			password: window.btoa(options.password),
  			cucm: options.cucm,
  			mode: options.mode,
  			device: options.device
  		},
        _registerPhoneCb);

  		return $this;
  	}
  
  	function unregisterPhone(options) {
  		var $this = this;
  		
  		_socket.emit('unregisterPhone');
  		
  		if ($.isFunction(options.complete)) { options.complete(); }
  		
  		return $this;
  	}
  	
  	function startConversation(options) {
  		var $this = this;
  		var container = $this;
  		
  		_socket.emit('startConversation', options.participant, function(error, conversation) {
  			if (error) {
  				return _triggerError(container, error, 'cannot start conversation');
  			}
  		
  			container
  				.addClass('cwic-conversation cwic-conversation-' + conversation.id)
  				.data('cwic', conversation)
    			.trigger('conversationStart.cwic', [conversation, container]);
		});
  		
  		/*
  		_webRTC.getUserMedia({ 'audio': true },
  			function(stream) {
  				_log(true, 'got user media', stream);
  				
				_createPeerConnection(stream);
  			},
  			function(error) {
  				_triggerError($this, error);
  			}
  		);
  		*/
  		
  		return $this;
  	} // startConversation
  	
  	function endConversation(options) {
  		var $this = this;
  		var container = $this;
  		
  		var divert = typeof options === 'boolean' ? options : false;
  		var conversation = container.data('cwic');
  		
  		_socket.emit('endConversation', divert, conversation, function(error, conversation) {
  			if (error) {
  				return _triggerError(container, error, 'cannot end conversation');
  			}
  			
  			container.trigger('conversationEnd.cwic', [conversation]);
  		});
  		
  		return $this;
  	} // endConversation
  
	function about() {
		return {
			javascript: {
  				version: '3.0.0.60683'
  			},
  			jquery: {
  				version: $.fn.jquery
  			},
  			plugin: {
  				version: {
  					plugin: 'N/A',
  					ecc: 'N/A'
  				}
  			}
  		};
  	}
  
    /**
    * _triggerError(target, [callback], [code], [data]) <br>
    * <br>
    * - target (Object): a jQuery selection where to trigger the event error from <br>
    * - callback (Function): an optional callback to be called call with the error. if specifed, prevents the generic error event to be triggered <br>
    * - code (Number): an optional cwic error code (defaults to 0 â€“ Unknown) <br>
    * - data (String, Object): some optional error data, if String, used as error message. if Object, used to extend the error. <br>
    * <br>
    * cwic builds an error object with the following properties: <br>
    *  code: a pre-defined error code <br>
    *  message: the error message (optional) <br>
    *  any other data passed to _triggerError or set to errorMap (see the init function) <br>
    *  <br>
    * When an error event is triggered, the event object is extended with the error properties. <br>
    * <br>
    */
    function _triggerError() {
        var $this = arguments[0]; // target (first mandatory argument)
        var errorCb = null;

        // the default error
        var error = $.extend({ details: [] }, errorMap.Unknown);

        // extend error from arguments
        for (var i=1; i<arguments.length; i++) {
            var arg = arguments[i];

            // is the argument a specific error callback ?
            if ($.isFunction(arg)) { errorCb = arg; }

            else if (typeof arg === "string") { error.details.push(arg); }

            else if (typeof arg === "object") { $.extend(error, arg); }

        } // for

        _log(error.message, error);

        // if specific error callback, call it
        if (errorCb) {
            errorCb(error);
        }
        else {
            // if no specific error callback, raise generic error event
            var event = $.Event('error.cwic');
            $.extend(event, error);
            $this.trigger(event);
        }

        return $this;
    }
    
	function _createPeerConnection(stream) {
		if (_webRTC.PeerConnection) {
			// http://dev.w3.org/2011/webrtc/editor/webrtc.html#rtcpeerconnection-interface
			//var pc = new _webRTC.PeerConnection('', function() { _log('PeerConnection constructor callback'); });
			
			try {
				var pc = new _webRTC.PeerConnection("STUN stun.l.google.com:19302", _onIceCandidate);
	
				pc.onconnecting = _onSessionConnecting;
				pc.onopen = _onSessionOpened;
				pc.onaddstream = _onRemoteStreamAdded;
				pc.onremovestream = _onRemoteStreamRemoved;
	
	
				pc.addStream(stream, null);
				var offer = pc.createOffer(null);
		
				pc.setLocalDescription(pc.SDP_OFFER, offer);
		
				var sdp = offer.toSdp();
				_log(true, sdp);
			}
			catch(e) {
				_log('cannot create peer connection', e);
			}
		}
		else {
			_log('PeerConnection is not available');
		}
	}
    
    function _onIceCandidate(candidate, moreToFollow) {
    	if (candidate) {
    		_log('_onIceCandidate label=', candidate.label);
    		_log(candidate.toSdp());
      	  	
      	  	/*
      	  	sendMessage({type: 'candidate',
          	           label: candidate.label, candidate: candidate.toSdp()});
          	*/
  		}
		
	    if (!moreToFollow) {
    	  _log("End of candidates.");
    	}
  	}
  	
  	function _onSessionConnecting(message) {
    	_log(true, "Session connecting.");
  	}
  	
	function _onSessionOpened(message) {
    	_log(true, "Session opened.");
    }

    function _onRemoteStreamAdded(event) {
    	_log(true, "Remote stream added.");
    }
    
    function _onRemoteStreamRemoved(event) {
    	_log(true, "Remote stream removed.");
  	}
  	
  
	  // a map with all exposed methods
  	var methods = {
  		init: init,
  		registerPhone: registerPhone,
  		unregisterPhone: unregisterPhone,
  		startConversation: startConversation,
  		endConversation: endConversation,
  		about: about
  	}
  
	$.fn.cwic = function( method ) {

    	try {
        	// Method calling logic
        	if ( methods[method] ) {
            	return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
        	}
        	else if ( typeof method === 'object' || ! method ) {
            	return methods.init.apply( this, arguments );
        	}
        	else {
            	throw method + ': no such method on jQuery.cwic';
        	}
    	}
    	catch(e) {
        	if(typeof console !== "undefined" && console.trace) {
            	console.trace();
        	}
        	_triggerError(this, e);
    	}
  	};
}(jQuery));
