/*
 * A SIP stack to register with Cisco CUCM
 *
 *
*/

var sip = require('sip');
var util = require('util');
var exec = exec = require('child_process').exec;
var events = require('events');

// the global settings:
// - the local IP address (required)
// - verbose: to print more logging [false]
// - log:     a function to log (msg, context) [util.log]
var settings = {
	localIp: null,
	userAgent: 'Cisco-CSF/9.2.1',
	verbose: false,
	log: function(msg, context) {
		util.log('sipcc - ' + msg);
		if (context) { util.log('sipcc - ' + util.inspect(context)); }
	}
};

// the active sessions
var sessions = {};

exports.session = function(clientid) {
    if (arguments[1] === null) {
        s = sessions[clientid];
        
        if (s) {
            _log('remove session ' + s.clientid);
            s.unregister({}, function(response) {
                if (response.status == 200) { _log('session unregistered'); }
            });
            
            delete sessions[s.clientid];
            delete sessions[s.contactUser];
            delete sessions[s.user];
        }
    }
    
    return sessions[clientid];
}

var remoteccRequest = '\
<?xml version="1.0" encoding="UTF-8"?>\n\
<x-cisco-remotecc-request>\n\
<softkeyeventmsg>\n\
<softkeyevent>IDivert</softkeyevent>\n\
<dialogid>\n\
<callid>$callid</callid>\n\
<localtag>$localtag</localtag>\n\
<remotetag>$remotetag</remotetag>\n\
</dialogid>\n\
<linenumber>0</linenumber>\n\
<participantnum>0</participantnum>\n\
<consultdialogid>\n\
<callid></callid>\n\
<localtag></localtag>\n\
<remotetag></remotetag>\n\
</consultdialogid>\n\
<state>false</state>\n\
<joindialogid>\n\
<callid></callid>\n\
<localtag></localtag>\n\
<remotetag></remotetag>\n\
</joindialogid>\n\
<eventdata>\n\
<invocationtype>explicit</invocationtype>\n\
</eventdata>\n\
<userdata></userdata>\n\
<softkeyid>0</softkeyid>\n\
<applicationid>0</applicationid>\n\
</softkeyeventmsg>\n\
</x-cisco-remotecc-request>';


/*************************************
 * an internal function to log messages
 * _log([isVerbose], msg, [context])
 *
 * isVerbose (Boolean): indicates if msg should be logged in verbose mode only (configurable by the application) 
 * msg (String): the message to be logged (to console.log by default, configurable by the application) 
 * context (Object): an optional context to be logged
*/
function _log() {
	var isVerbose = typeof arguments[0] === "boolean" ? arguments[0] : false;
	var msg = typeof arguments[0] === "string" ? arguments[0] : arguments[1];
	var context = typeof arguments[1] === "object" ? arguments[1] : arguments[2];
	
	if ((!isVerbose || (isVerbose && settings.verbose))) {
		settings.log('sipcc - ' + msg, context);
	}
}

/**************************************
 * an internal function to generate UUIDs
 * depends on the node-uuid module
 * see https://github.com/broofa/node-uuid
 */
function _uuid() {
	var uuid = require('node-uuid')();
		
	// check if uuid matches 8-4-4-4-12
	var m = uuid.match(/(\w{8})\-(\w{4})\-(\w{4})\-(\w{4})\-(\w{12})/);
	if (m) {
		// rearrange uuid to match 8-8-8-8
		uuid = m[1] + '-' + m[2] + m[3] + '-' + m[4] + m[5].substr(0,4) + '-' + m[5].substr(4);
	}

	return uuid;
}

// public function to initialize and start the stack
// options can be used to override default settings
exports.start = function(options) {
	var startOptions = {};

	if (typeof options.verbose === 'boolean') { settings.verbose = options.verbose; }
	if (typeof options.log === 'function')    {
		settings.log = options.log;

		startOptions.logger = {
			send: function(msg, address) {
				if (!settings.verbose) { return; }
				
				var uri = /*typeof msg.uri === "object" ? sip.stringify(msg.uri) :*/ msg.uri;
				var from = '', to = '';
				try {
					from = sip.stringifyUri(msg.headers.from.uri);
					to = sip.stringifyUri(msg.headers.from.uri);
				}
				catch(e) {}
				
				var prefix = from + ' => ' + to + ' ';
				if (msg.method) {
					_log(true, prefix + msg.method + ' ' + uri);
				}
				else {
					_log(true, prefix + msg.status + ' ' + msg.reason + ' [' + msg.headers.cseq.method + ']');
				}
			},
			recv: function(msg, address) {
				if (!settings.verbose) { return; }
				
				var uri = /*typeof msg.uri === "object" ? sip.stringify(msg.uri) :*/ msg.uri;
				var from = '', to = '';
				try {
					from = sip.stringifyUri(msg.headers.from.uri);
					to = sip.stringifyUri(msg.headers.from.uri);
				}
				catch(e) {}
				
				var prefix = from + ' <= ' + to + ' ';
				if (msg.method) {
					_log(true, prefix + msg.method + ' ' + uri);
				}
				else {
					_log(true, prefix + msg.status + ' ' + msg.reason + ' [' + msg.headers.cseq.method + ']');
				}
			}	
		};
	}

	_log('start');

	// get local ip
	var interfaces = require('os').networkInterfaces();
	for (i in interfaces) {
    	for (j in interfaces[i]) {
        	var addr = interfaces[i][j];
	        if (addr.family == 'IPv4' && !addr.internal && !settings.localIp) {
            	settings.localIp = addr.address;
            	_log('local ip is ' + settings.localIp);
	        }
    	}
	}
	
	sip.start(startOptions, function(request, remote) {
		_log(true, 'received ' + request.method);
		//if (/NOTIFY/i.test(request.method)) { _log(true, sip.stringify(request)); }
		
		var uri = sip.parseUri(request.uri);
		try {
			var session = sessions[uri.user];
			
			if (!session && uri.params && uri.params.clientid) {
				session = sessions[uri.params.clientid];
			}

			if (session) {
				var context = session.context(request);
				if (!context.originalRequest) { context.originalRequest = request; }
				session.emit(request.method.toLowerCase(), request);
			}
			else {
				_log('no session for request uri "' + request.uri + '"');
				// temporary
				sip.send(sip.makeResponse(request, 200, 'OK'));
			}
		}
		catch(e) {
			_log('error while receiving request: ' + e.message);
		}
	});	
	
} // start

// public function to stop the stack
exports.stop = function() {
	_log('stop');
	
	sip.stop();
}


// the Session constructor
function Session () {
	var self = this;
	events.EventEmitter.call(self);
	
	self.reset = function() {
		// a map whose keys are callIds
		self.contexts = {};
		
		// static configuration
		self.config = {};
		
		// registration info
		self.register = {
			timeout: null,
			contextId: ''
		};
	};
	
	self.reset();
	
	// build and return a context identifier
	self.contextId = function(id) {
		if (typeof id === 'string') { return id; }
		
		if (typeof id === 'object' && typeof id.headers === 'object') {
			return id.headers['call-id'].substr(0, id.headers['call-id'].indexOf('@'));
		}
		
		return '';
	}
	
	// context (call) management:
	// add or update: context(msg)
	//                context(id, msg)
	// retrieve only: context(msg, false)
	//                context(id, false)
	// remove:        context(msg, null)
	//                context(id, null)
	// returns the context or null
	self.context = function() {
		var contextId = self.contextId(arguments[0]);
		
		var context = self.contexts[contextId];
		
		var msg = typeof arguments[0] === 'object' ? arguments[0] :
		    typeof arguments[1] === 'object' ? arguments[1] : undefined;
		
		if (!context) {
			if (false === arguments[1]) {
				// retrieve only
				return null;
			}
			
			// add
			_log('session ' + self.clientid + ' add context ' + contextId);
			return self.contexts[contextId] = {
				headers: msg.headers || {}
			};
		}
		else {
			// context exists
			if (typeof arguments[1] === 'undefined') {
				// update
				if (msg) { context.headers = msg.headers; }
			}
			else if (null === arguments[1]) {
				// remove
				_log('session ' + self.clientid + ' remove context ' + contextId);
				delete self.contexts[contextId];
				_log('session ' + self.clientid + ' has ' + Object.keys(self.contexts).length + ' contexts');
			}
		}

		return context;
	}
};

util.inherits(Session, events.EventEmitter);

// send a message with an optional callback to handle dialog responses
Session.prototype.send = function(msg, callback) {
	var session = this;
	
	if (!msg.headers['user-agent']) { msg.headers['user-agent'] = settings.userAgent; }
	if (!msg.headers['max-forwards']) {	msg.headers['max-forwards'] = '70'; }

	// generate call-id if needed
	if (!msg.headers['call-id']) { msg.headers['call-id'] = _uuid() + '@' + settings.localIp; }
	
	// set or update date
	msg.headers.date = new Date().toUTCString();

    try {
    	// msg is ready, send it
	    sip.send(msg, callback);
	    
	    if (msg.status == 200) { session.context(msg, null); } // TEMP ?
	}
	catch(e) {
	    _log('cannot send message:' + e.message);
	}
}


// returns a response object for request with status and reason fields set.
Session.prototype.makeResponse = function(request, status, reason) {
	return sip.makeResponse(request, status, reason);
}


// a helper function to register with CUCM with parameters:
// - cucm: the CUCM address
// - device: the device name (ex: ECPuser)
// - contact: contact id retrived from device configuration
exports.register = function(options, callback) {
	_log(true, 'register');
	var session = new Session();
	session.config = options;
		
	var reg = {
		method: 'REGISTER',
		uri: {
			schema: 'sip',
			host: session.config.cucm,
			params: { clientid: session.config.clientid }
		},
		version: '2.0',
		headers: {
			from: {
				uri: {
					schema: 'sip',
					user: session.config.line,
					host: session.config.cucm,
					params: { clientid: session.config.clientid }
				}
			},
			to:   {
				uri: {
					schema: 'sip',
					user: session.config.line,
					host: session.config.cucm,
					params: { clientid: session.config.clientid }
				}
			},
			//'call-id': settings.options.callId || null,
			cseq: { method: 'REGISTER', seq: '1' },
			contact: [{
				uri: {
					schema: 'sip',
					user: session.config.contact,
					host: settings.localIp,
					params: { clientid: session.config.clientid }
				},
				params: {
					transport: 'tcp',
					//'+sip.instance': '"<urn:uuid:00000000-0000-0000-0000-303031613662>"',
					'+u.sip!devicename.ccm.cisco.com': '"' + session.config.device + '"',
					'+u.sip!model.ccm.cisco.com': '"503"'
				}
			}],
			supported: 'replaces,join,norefersub,extended-refer,X-cisco-callinfo,X-cisco-serviceuri,X-cisco-escapecodes,X-cisco-service-control,X-cisco-srtp-fallback,X-cisco-monrec,X-cisco-config,X-cisco-sis-3.0.0,X-cisco-xsi-,X-cisco-duplicate-reg',
			'content-length': 0,
			expires: 3600
		}
	};
	
	function _onResponse(response) {
	    //_log(sip.stringify(response));
        
		if (response.status == 200) {
			session.register.contextId = session.contextId(response);
		
			if (callback) {
				// one-time applicative callback
				callback(null, session);
				callback = null;
				
				//_log(require('util').inspect(response.headers.to.uri));
				var toUri = sip.parseUri(response.headers.to.uri);
				session.user = toUri.user;
				sessions[session.user] = session;
				_log(true, 'add session for user ' + session.user);
				
				try {
					var contactUri = sip.parseUri(response.headers.contact[0].uri);
					//_log(require('util').inspect(contactUri));
					session.contactUser = contactUri.user;
					sessions[session.contactUser] = session;
					_log(true, 'add session for contact ' + session.contactUser);
					
					if (contactUri.params && contactUri.params.clientid) {
						session.clientid = contactUri.params.clientid;
						sessions[session.clientid] = session;
						_log(true, 'add session for clientid ' + session.clientid);
					}
				}
				catch(e) {
					_log(e.message);
				}
			}
			
			ctx = session.context(response);
            if (!ctx.originalRequest) { ctx.originalRequest = reg; }
			
			if (response.headers.expires) {
				// maintain registration
				session.register.timeout =
					setTimeout(function(session) {
						//_log(true, require('util').inspect(session));
						//_log(true, 'session.register.contextId=' + session.register.contextId);
						var register = session.context(session.register.contextId).originalRequest;
						register.headers.via = [];
						session.send(register, _onResponse); 
					},
					(response.headers.expires / 2) * 1000, session);
			}
		}
	}

    //_log(sip.stringify(reg));
	session.send(reg, _onResponse);
		
} // register

Session.prototype.unregister = function(options, callback) {
	_log(true, 'unregister');
	var session = this;

	var unreg = {
		method: 'REGISTER',
		uri: 'sip:' + session.config.cucm,
		version: '2.0',
		headers: session.context(session.register.contextId).headers || {}
	};
	unreg.headers.expires = 0;
	
	if (session.register.timeout) {
		clearTimeout(session.register.timeout);
		session.reset();
	}
	//_log(sip.stringify(unreg));
	session.send(unreg, function(response) {
	    if (response.status == 200) {
	        session.context(response, null);
	        //_log(require('util').inspect(sessions));
	        delete sessions[session.user];
	        delete sessions[session.contactUser];
	        delete sessions[session.clientid];
	        //_log(require('util').inspect(sessions));
	    }
	    else {
    		session.context(response);
    	}
    	
		callback(response);
	});
}


// helper function to send an INVITE request with parameters:
// - dialstring: the phone number to call
Session.prototype.invite = function(options, callback) {
	_log(true, 'invite');
	var session = this;

	var fromUri = 'sip:' + session.config.line + '@' + session.config.cucm;
	var toUri = 'sip:' + options.dialstring + '@' + session.config.cucm;

	var inv = {
		method: 'INVITE',
		uri: toUri,
		version: '2.0',
		headers: {
			from: { uri: fromUri },
			to:   { uri: toUri },
			allow: 'ACK,BYE,CANCEL,INVITE,NOTIFY,OPTIONS,REFER,REGISTER,UPDATE,SUBSCRIBE,INFO',
			accept: ['application/sdp'],
			'remote-party-id': '"' + session.config.displayName + '" <' + fromUri + '>;party=calling;id-type=subscriber;privacy=off;screen=yes',
			cseq: { method: 'INVITE', seq: '1' },
			contact: [{
				uri: 'sip:' + session.config.contact + '@' + settings.localIp,
				params: {
					transport: 'tcp',
					//'+sip.instance': '"<urn:uuid:00000000-0000-0000-0000-303031613662>"',
					'+u.sip!devicename.ccm.cisco.com': '"' + session.config.device + '"',
					'+u.sip!model.ccm.cisco.com': '"503"'
				}
			}],
		}
	};

	
	session.send(inv, function(response) {
		//_log(true, sip.stringify(response));
		
		if (response.status == 487) {
			// request cancelled
			var ack = { headers: {} };
			ack.method = 'ACK';
			ack.uri = response.headers.to.uri;
			ack.headers.to = response.headers.to;
			ack.headers.from = response.headers.from;
			ack.headers.cseq = { method: 'ACK', seq: '101' };
			session.send(ack);
		}
		else {
			var context = session.context(response);
			if (!context.originalRequest) { context.originalRequest = inv; }
		}
		
		callback(null, response);
	});
}

// helper function to bye
Session.prototype.bye = function(options, callback) {
	_log(true, 'bye callId=' + options.callId);
	var session = this;
	
	if (!options.callId) {
		callback({ message: 'missing call id' });
		return;
	}
	
	var call = session.context(options.callId, false);
	if (!call) {
		callback({ message: 'unknown call id ' + options.callId });
		return;
	}
	
	//var bye = sip.copyMessage(call.originalRequest);
	var bye = {};
	bye.method = 'BYE';
	bye.uri = call.originalRequest.uri;
	bye.headers = {};
	bye.headers.from = call.headers.from;
	bye.headers.to = call.headers.to;
	bye.headers['call-id'] = call.headers['call-id'];
	bye.headers['user-agent'] = settings.userAgent;
	bye.headers.cseq = { method: 'BYE', seq: '103' };
	bye.headers.via = call.headers.via;

	
	session.send(bye, function(response) {
	    if (response.status == 200) {
    		session.context(options.callId, null);
	    	call = null;
	    }
	    
		callback(null, response);
	});
}

// helper function to cancel
Session.prototype.cancel = function(options, callback) {
	_log(true, 'cancel');
	var session = this;

	if (!options.callId) {
		callback({ message: 'missing call id' });
		return;
	}
	
	var call = session.context(options.callId);
	if (!call) {
		callback({ message: 'unknow call id ' + options.callId });
		return;
	}

	var can = sip.copyMessage(call.originalRequest);
	can.method = 'CANCEL';
	can.headers.cseq = { method: 'CANCEL', seq: '1' };
	session.send(can, function(response) {
		session.context(response, null);
		call = null;
		callback(null, response);
	});
}

// helper function to refer
Session.prototype.refer = function(options, callback) {
	_log(true, 'refer');
	var session = this;
	
	if (!options.callId) {
		callback({ message: 'missing call id' });
		return;
	}
	
	var call = session.context(options.callId);
	if (!call) {
		callback({ message: 'unknow call id ' + options.callId });
		return;
	}
	
	var ref = {
    	method: 'REFER',
    	uri: 'sip:' + session.config.cucm,
    	headers: {}
    };
	
	ref.content = remoteccRequest
	    .replace('$callid', call.headers['call-id'])
		.replace('$localtag', call.headers.to.params.tag)
		.replace('$remotetag', call.headers.from.params.tag);
	
	ref.headers.to = call.headers.from;
	ref.headers.from = call.headers.to;
	ref.headers.to.params = {};
	ref.headers.from.params = {};
	ref.headers.cseq = { method: 'REFER', seq: '101' };
	ref.headers.contact = call.originalRequest.uri;
	ref.headers['user-agent'] = settings.userAgent;
	//ref.headers['call-id'] = 'OutOfDialog--0007-5fd502e8-655d891d@' + settings.localIp; // TEMP
	ref.headers['referred-by'] = call.originalRequest.headers.to.uri;
	ref.headers['refer-To'] = 'cid:7f116bb2@' + settings.localIp; // TEMP
	ref.headers['require'] = 'norefersub';
	ref.headers['content-disposition'] = 'session;handling=required';
	//ref.headers['content-id'] = 'cid:7f116bb2@' + settings.localIp; // TEMP
	ref.headers['content-type'] = 'application/x-cisco-remotecc-request+xml';
	
	session.send(ref, function(response) {
		//_log(true, sip.stringify(response));
		if (response.status === 202) {
    		// accepted
    		session.context(response, null);
		}
		else {
		    session.context(response);
		}
		
		callback(null, response);
	});
	
	//_log(sip.stringify(ref));
}

exports.Session = Session;

exports.parseUri = sip.parseUri
