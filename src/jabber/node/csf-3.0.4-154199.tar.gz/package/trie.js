
var util = require('util');

exports.Trie = Trie = function() {
	this._node = new Trie.Node();
}


Trie.Node = function(parent) {
	this.parent = parent || null;
	this.children = {};
	this.data = []; // array of NodeData
}

Trie.NodeData = function(data) {
	this.creationDate = new Date();
	this.data = data;
}

Trie.prototype.add = function(key, data) {
	Trie.add(this._node, key, data);
}

Trie.prototype.subtree = function(key, cb) {
	Trie.subtree(this._node, key, cb);
}

Trie.prototype.collect = function(key, cb) {
	Trie.collect(this._node, key, cb);
}

Trie.prototype.print = function() {
	Trie.print(this._node);
}

Trie.add = function(node, key, data) {

	first = key.charAt(0);
	
	if (first == "") {
		node.data.push(new Trie.NodeData(data));
	}
	else {
		var child = node.children[first];
	
		if (!child) {
			child = new Trie.Node(node);
			node.children[first] = child;
		}

		// forward to child		
		Trie.add(child, key.substring(1), data);
	}
}

Trie.subtree = function(node, key, cb) {

	// find subtree root
	first = key.charAt(0);
	child = node.children[first];
	
	if (child) {
		Trie.subtree(child, key.substring(1), cb);
	}
	else if (first == "") {
	
		// match whole subtree
	
		function matchSubtree(node, cb) {
			for (var i=0; i<node.data.length; i++) {
				cb(node.data[i].data);
			}
		
			for (var c in node.children) {
				matchSubtree(node.children[c], cb);
			}
		}
	
		if (cb) {
			matchSubtree(node, cb);
		}
	}
	else {
		util.debug("trie - no subtree for '" + key + "'");
	}
}

Trie.collect = function(node, key, cb) {

	var res = []; // array of results
	
	Trie.subtree(node, key, function(data) { res.push(data); });

	if (cb) { cb(res); }
}

Trie.print = function(node, prefix) {
	var prefix = prefix || "";
	
	util.debug("trie - " + prefix + "data.length=" + node.data.length);
	
	for (var i in node.children) {
		Trie.print(node.children[i], prefix + "-" + i);
	}
}