
// Quick Contact CSF module

var http = require('http');
var ldap = require('ldapjs');
var trie = require('csf/trie');

var nameTrie = new trie.Trie();

// key is CN, value is contact
var cachedContacts = {};

var logger = require('csf/logger').createLogger('quickcontact');
var properties = require('csf/properties').createProperties('quickcontact', logger);

var mapping = {};

var ldapClient = null;

var searchAttributes = [];
searchAttributes.push('cn');


exports.initialize = function(app, config, io) {

	logger.configure({
		verbose: config.verbose
	});

    properties.setValues(config);
    properties.createRoutes(app);
	
	// init mapping
	mapping = properties.get('ldap').mapping;
	for (var csf in mapping) {

		if (csf == "phoneNumbers") {
			for (var phone in mapping[csf]) {
				searchAttributes.push(mapping[csf][phone]);
			}
		}
		else {
		    searchAttributes.push(mapping[csf]);
		}
	}

	// create routes
	logger.log(true, 'create routes');
	
	app.get('/quickcontact/view', function (req, res) {
		res.sendfile(__dirname + '/view.html');
	});
	
	app.get('/quickcontact/name/:name?', function(req, res, next) {

        searchName({
        	name: req.params.name,
            photo: req.query.photo == "yes",
            max: req.query.max
	    },
	    function(error, contacts) {
	    	respondRoute(error, contacts, req, res, next);
	    });
		
		/*
		nameTrie.collect(name, function(cns) {
			//logger.log(true, "collected " + cns.length + " from trie (key=" + name + ")");
			
			for (var i=0; i<cns.length; i++) {
				cn = cns[i];
				result[cn] = cachedContacts[cn];
				resultLen++;
			}
		});
		*/
		
		/*
			success: function(contacts) {
				logger.log(true, 'success - found ' + contacts.length + ' contacts');
			
				for (var i=0; i<contacts.length; i++) {
					contact = contacts[i];
				
					cn = contact.cn.toLowerCase();
					
					if (!cachedContacts[cn]) {
						logger.log(true, 'caching cn=' + cn);
						cachedContacts[cn] = contact;
					
						// store contact CN in the trie for quick retrieval
						if (contact.screenName) {
							nameTrie.add(contact.screenName.toLowerCase(), cn);
						}
					
						if (contact.displayName) {
							nameTrie.add(contact.displayName.toLowerCase(), cn);
						}
					
						if (contact.firstName) {
							nameTrie.add(contact.firstName.toLowerCase(), cn);
						}
					
						if (contact.lastName) {
							nameTrie.add(contact.lastName.toLowerCase(), cn);
						}
					}
					
					// add more results
					if (!result[cn]) { result[cn] = contact; resultLen++; }
				}
			}
		});
		*/
		
	});
	
	app.get('/quickcontact/uri/:uri?', function(req, res, next) {
	    
        searchUri({
        	uri: req.params.uri,
            photo: req.query.photo == "yes",
            max: req.query.max
	    },
	    function(error, contacts) {
	    	respondRoute(error, contacts, req, res, next);
	    });
	    
	});
	
	app.get('/quickcontact/email/:email?', function(req, res, next) {
	    
        searchEmail({
        	email: req.params.email,
            photo: req.query.photo == "yes",
            max: req.query.max
	    },
	    function(error, contacts) {
	    	respondRoute(error, contacts, req, res, next);
	    });
	    
	});
	
    app.get('/quickcontact/phoneNumber/:phoneNumber?', function(req, res, next) {
   
        searchPhoneNumber({
        	phoneNumber: req.params.phoneNumber,
        	cc: req.query.cc,
            photo: req.query.photo == "yes",
            max: req.query.max
	    },
	    function(error, contacts) {
	    	respondRoute(error, contacts, req, res, next);
	    });
    
    });

    // support socket.io (web sockets) if available
    if (io) {
    	logger.log('socket transport enabled');

    	io.of('/quickcontact/socket').on('connection', function(socket) {
			logger.log(true, 'new connection socket.id=' + socket.id);

			socket.on('search-name', function(params, cb) {
				searchName(params, cb);
			});

			socket.on('search-uri', function(params, cb) {
				searchUri(params, cb);
			});

			socket.on('search-email', function(params, cb) {
				searchEmail(params, cb);
			});

			socket.on('search-phoneNumber', function(params, cb) {
				searchPhoneNumber(params, cb);
			});

		});
    }

	// Open a connection.
	url = "ldap://" + properties.get('ldap').host + ":" + properties.get('ldap').port;
	logger.log("connecting to " + url);
	
	ldapClient = ldap.createClient({
		url: url,
		bindDN: properties.get('ldap').credentials.user,
		bindCredentials: properties.get('ldap').credentials.password,
		maxConnections: 2
	});
	
	ldapClient.bind(
		properties.get('ldap').credentials.user,
		properties.get('ldap').credentials.password,
		function(err) {
			if (err) { logger.log('cannot bind to LDAP directory: ' + err); }
			else     { logger.log('connected to LDAP directory'); }
		}
	);
	
}; // end of initialize


function respondRoute(error, contacts, req, res, next) {
 
	if (error) {
		res.send(500, error);
	}
	else {
		// send HTTP response
        if (req.query.callback) {
			res.send({data: contacts}); // JSONP
		}
		else {
	        res.send(contacts);
	    }
	}
}

function searchName(params, cb) {
	params.filter = '(|'
			+ '(' + mapping['screenName'] + '=' + params.name + '*)'
			+ '(' + mapping['displayName'] + '=' + params.name + '*)'
			+ '(' + mapping['firstName'] + '=' + params.name + '*)'
			+ '(' + mapping['lastName'] + '=' + params.name + '*)'
			+ ')';

	searchLdap(params, cb);
}

function searchUri(params, cb) {
	params.filter = '(' + mapping['uri'] + '=sip:' + params.uri + '*)';

	searchLdap(params, cb);
}

function searchEmail(params, cb) {
	params.filter = '(' + mapping['email'] + '=' + params.email + '*)';

	searchLdap(params, cb);
}

function searchPhoneNumber(params, cb) {
	var phoneNumber = params.phoneNumber + '';
   	if (params.cc == "yes") { phoneNumber = '+' + phoneNumber; }
   		
    params.filter = '(|';
        
    for (var phoneType in mapping['phoneNumbers']) {
        params.filter += ' (' + mapping['phoneNumbers'][phoneType] + '=' + phoneNumber + ')';
    }

    params.filter += ')';

	searchLdap(params, cb);
}

/*
	params is an object which can contain:
	- filter: an LDAP filter string (required)
	- max: a maximum number of results (number, 10 by default)
	- photo: true to include photo in results (false by default)
*/
function searchLdap(params, cb) {

	var args = {
		filter: '',
		photo: false,
		max: 20,
		treebase: properties.get('ldap').treebase,
		scope: 'sub',
		attrs: searchAttributes
	}.extend(params);

	if (!args.max || args.max <= 0 || args.max > 20) { args.max = 20; } // this should be configurable by the node admin

    ldapClient.search(args.treebase, {
    	scope: args.scope,
    	filter: args.filter,
    	attributes: args.attrs,
    	sizeLimit: typeof args.max === 'string' ? parseInt(args.max) : args.max
    	},
    	function(err, res) {

    		if (err) {
    			logger.log('search error ' + err);
    			return cb(err);
    		}

    		var contacts = [];
    	
	    	res.on('searchEntry', function(entry) {
				var entityAttributes = entry.attributes || [];
	    		var contact = {};
	    		
	    		// transform entity attributes array into map
	    		// key is attribute type, value is array of values
	    		var attributes = {};
				for (var i = 0; i < entityAttributes.length; i++) {
					attr = entityAttributes[i];
					attributes[attr.type.toLowerCase()] = attr.vals;
				}
	    		
    			contact.cn = (attributes.cn || [])[0];
    		
	    		for (var csf in mapping) {
    				if (csf == "phoneNumbers") {
    					contact[csf] = {};
    				
    					for (var phone in mapping[csf]) {
    						ldap = (mapping[csf][phone]).toLowerCase();
    						
    						if (attributes[ldap]) {
    							contact[csf][phone] = attributes[ldap][0].replace(/[\(\)\-\s\[\]\.]/g, '');
    						}
    					}
    			
	    				continue;
    				}
    		
    				ldap = mapping[csf];
    			
    				if (attributes[ldap]) {
    					contact[csf] = attributes[ldap][0];
    				}
    			}
    		
	    		if (!args.photo || !contact.screenName) {
    				// skip photo
    				contacts.push(contact);
	    			return;
    			}
    		
    			if (mapping.photosrc) {
	    			contact.photosrc = mapping.photosrc.replace(/\{screenName\}/g, contact.screenName);
    			}
    		
    			contacts.push(contact);
    		
				/*
				var phototype = 'jpg'; // should be configurable
				
				http.get({
					host: 'my.com',
					port: 80,
					path: '/photo/std/' + contact.screenName + '.' + phototype
				},
				function(res) {
	
					var chunks = [];
					var photosize = 0;
		
					res.on('data', function(chunk) {
						// chunk is a Buffer
						chunks.push(chunk);
						photosize += chunk.length;
					});
		
					res.on('end', function() {
						if (res.statusCode == 200) {
							// concatenate all chunks
							var photo = new Buffer(photosize);
							var index = 0;
			
							for (i=0; i<chunks.length; i++) {
								chunks[i].copy(photo, index);
								index += chunks[i].length;
							}
							
							contact.photosrc = 'data:image/' + phototype + ';base64,' + photo.toString('base64');
						}
					
						contacts.push(contact);
						
						// add more contacts
						addContact(results.shift());
					});
		
				});
				*/
			});
    
    		res.on('error', function(err) {
				var result = [];
				if (err.name == 'SizeLimitExceededError' || err.name == 'TimeLimitExceededError') {
					// partial result
					return cb(null, contacts);
				}

				logger.log('search error');
				logger.log(require('util').inspect(err, false, 4));
				logger.log('err.code=' + err.code + ' - ' + typeof(err.code));
				logger.log('err.name=' + err.name + ' - ' + typeof(err.name));
				logger.log('err.message=' + err.message + ' - ' + typeof(err.message));
				
				cb(err);
    		});
    		
    		res.on('end', function(result) {
    			//logger.log(true, 'search result: ' + result);

    			cb(null, contacts);
    		});
    	} // search callback
    ); // searchLdap
}
