
var fs = require('fs');
var tftpclient = require('csf/tftpclient');
var ccmcipclient = require('csf/ccmcipclient');

var logger = require('csf/logger').createLogger('phoneconfig');
var properties = require('csf/properties').createProperties("phoneconfig", logger);

function findCucmCluster(plus, digits) {
    // digits
    phoneNumber = digits;
    
    // prepend '+' if needed
    if (plus) {
       phoneNumber = "+" + phoneNumber;
    }
    
    logger.log(true, "get cluster from phoneNumber=" + phoneNumber);
    rules = properties.get('cucmClusterDnRule');
    
    // match a rule to find cluster name
    for (var i=0; i<rules.length; i++) {
       rule = new RegExp('^' + rules[i][0].replace(/X/g, '\\d').replace(/\+/g, '\\+') + '$');
       
       if (phoneNumber.match(rule)) {
           // find the cluster definition from name
           clusterName = rules[i][1];
           
           clusters = properties.get('cucmCluster');
           if (clusters && clusters[clusterName]) {
               return { cluster: clusters[clusterName], phoneNumber: phoneNumber };
           }
       }
    }
    
    return { phoneNumber: phoneNumber };
}


exports.initialize = function(app, config) {
	logger.configure({
		verbose: config.verbose
	});

    properties.setValues(config);
    properties.createRoutes(app);
	
	app.get('/phoneconfig/view', function(req, res) {
		res.sendfile(__dirname + '/view.html');
	});
	
	app.get('/phoneconfig/cucmCluster/name/:name', function(req, res) {
	   
	   cluster = properties.get('cucmCluster')[req.params.name];
	   if (cluster) {
	       res.send(cluster, { 'Content-Type': 'application/json' });
	       return;
	   }
	   
	   res.send("unknown cucm cluster '" + req.params.name + "'", 404);
	});
	
	// get CUCM cluster from phone number:
	// GET /phoneconfig/cucmCluster/phoneNumber/81384716
	// GET /phoneconfig/cucmCluster/phoneNumber/plus/35391384716
	app.get(/^\/phoneconfig\/cucmCluster\/phoneNumber(?:\/(plus))?\/(\d+)$/, function(req, res) {
	    
        result = findCucmCluster(req.params[0], req.params[1]);
	    
	    if (result.cluster) {
	        res.send(result.cluster, { 'Content-Type': 'application/json' });
	        return;
	    }
	    
	    res.send({ error: "no cucm cluster found from phone number " + result.phoneNumber }, 404);
	});
	
	app.get('/phoneconfig/device/user/:user/phoneNumber/:phoneNumber/client/:client', function(req, res) {
	    
	    var result = findCucmCluster(null, req.params.phoneNumber);
	    
	    if (!result.cluster) {
	       res.send("no cucm cluster found from phone number " + result.phoneNumber, 404);
	       return;
	    }
	    
		readDeviceConfig({
			user: req.params.user,
			tftp: result.cluster.primaryNode,
			client: req.params.client,
			success: function(config) {
				res.send(merger.extend(config, { cucmCluster: result.cluster }));
			},
			error: function(error) {
				res.send(error);
			}
		});
	});
	
	app.get('/phoneconfig/device/user/:user/client/:client', function(req, res) {
		
		readDeviceConfig({
			user: req.params.user,
			tftp: req.query.tftp,
			client: req.params.client,
			success: function(config) {
				if (req.query.callback) {
					res.send({data: config}); // JSONP
				}
				else {
					res.send(config);
				}
			},
			error: function(error) {
				if (req.query.callback) {
					res.send({error: error}, 404); // JSONP
				}
				else {
					res.send(error, 404);
				}
			}
		});
	});
	
	function readDeviceConfig(args) {
	
		if (!args.tftp) {
			if (args.error) { args.error("no device: missing TFTP address"); }
			return;
		}
	
		deviceNamePattern = 'ECP{user}'; //properties.get('deviceNamePattern')[args.client];
	    
	    if (!deviceNamePattern) {
	        if (args.error) { args.error("no device: missing pattern for client '" + args.client + "'"); }
		    return;
	    }
	    
	    if (!args.user) {
	    	if (args.error) { args.error("no device for missing user name"); }
	    	return;
	    }
	    
	    var deviceName = deviceNamePattern.replace(/\{user\}/g, args.user);
			    
	    tftpclient.readFile({
	        server: args.tftp,
	        filename: deviceName + ".cnf.xml",
	        success: function(buffer) {
				if (args.success) {
					args.success({ name: deviceName, tftp: args.tftp, configuration: buffer.toString('ascii') });  
	           	}
	        },
	        error: function(error) {
	       		if (args.error) { args.error(error); }
	       }
	    });
	}
	
	app.get('/phoneconfig/devices', function(req, res) {
		// support Basic authentication
		if (m = /Basic\s+(.*)$/i.exec(req.header('Authorization', ''))) {
			var auth = new Buffer(m[1], 'base64').toString().split(':');
			
			ccmcipclient.getDevices({
				userName: auth[0] || '',
				userPassword: auth[1] || '',
				ccmcipHost: req.query.ccmcip,
				success: function(devices) {
					logger.log(true, 'ccmcip returned ' + devices.length + ' devices');
					res.send(devices);
				},
				error: function(ccmcipRes) {
					logger.log(true, 'cmmcip returned error status ' + ccmcipRes.statusCode);
					res.send(ccmcipRes.statusCode);
				}
			});
		}
		else {
			res.header('WWW-Authenticate', 'Basic realm="CUCM User"');
    		res.send('Authentication required', 401);
		}
	});
};

