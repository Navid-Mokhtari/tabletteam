
module.exports = require('./hello.js');
