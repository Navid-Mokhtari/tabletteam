
var path = require('path');
var fs = require('fs');

var logger = require('csf/logger').createLogger('problemreport');
var properties = require('csf/properties').createProperties('problemreport', logger);

exports.initialize = function(app, config) {
	var reportsRoot = config.reportsDir || '/var/csf/problemreport/';
	
	properties.createRoutes(app);
	
	// serve static UI files
	app.get('/problemreport/?', function(req, res) {
		res.redirect('/problemreport/index.html');
	});
	app.get('/problemreport/:file.(js|html|png)', function(req, res) {
		res.sendfile(__dirname + '/www/' + req.params.file + '.' + req.params[0]);
	});
	
	app.post('/problemreport/submit', function(req, res) {	
	    now = new Date();
        var reportId = '' + now.getFullYear() + ('00' + (now.getMonth() + 1)).slice(-2) + ('00' + now.getDate()).slice(-2);
        reportId += '-' + ('00' + now.getHours()).slice(-2) + ('00' + now.getMinutes()).slice(-2) + ('00' + now.getSeconds()).slice(-2);
		reportId += '-' + (req.body.username || 'unknown');
		if (req.body.identifier) { reportId += '-' + req.body.identifier; }
		
		logger.log(true, 'creating reportId=' + reportId);
		
		var reportDir = reportsRoot + 'reports/' + reportId;
		fs.mkdir(reportDir, function(exception) {
			if (exception) {
				res.send(500, exception);
				return;
			}
			
			function _writeReportFile(file) {
				fs.writeFile(reportDir + '/' + file.name, fs.readFileSync(file.path), function(err) {
					logger.log(true, 'unlink ' + file.path);
					fs.unlinkSync(file.path);
				
					if (err) {
						res.send(500, err); return;
					}
				
					var info = '';
					info += 'Submit date : ' + now + '\n';
					info += 'Username    : ' + (req.body.username || 'empty') + '\n';
					info += 'Platform    : ' + req.body.platform + '\n';
					info += 'User agent  : ' + req.body.userAgent + '\n';
					info += 'Identifier  : ' + (req.body.identifier || 'empty') + '\n';
					info += 'Description :\n';
					info += req.body.description;
					
					fs.writeFileSync(reportDir + '/info.txt', info || 'empty');
				});
			}
			
			if (req.files.file1) { _writeReportFile(req.files.file1); }
			if (req.files.file2) { _writeReportFile(req.files.file2); }
			if (req.files.file3) { _writeReportFile(req.files.file3); }
			
			res.send({
				id: reportId
			});
		});
    });
    
    // serve reports statically
	var express = require('express');
	app.use('/problemreport', express.directory(reportsRoot));
	app.use('/problemreport', express.static(reportsRoot));
    
    /*
    app.get('/problemreport/:reportId.zip', function(req, res) {
    	
    });
    */
}
